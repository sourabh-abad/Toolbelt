# LinkedIn posts — DevPocket

LinkedIn does not render markdown. No bold, no italics, no bullets with `-`.
Use line breaks and plain characters (→ · —) for structure. Copy the plain
text inside each block exactly as-is.

Only the first 2–3 lines show before "…see more", so the opening line has to
earn the click on its own.

---

## Option A — the story (recommended)

Best all-round: personal, specific, and the privacy point lands without preaching.

```
I was debugging an auth issue at 11pm when I caught myself doing something
I'd done a hundred times without thinking.

I copied a JWT out of a production log, searched "jwt decoder", clicked the
first result, and pasted it in.

Then I stopped. That token belonged to a real user. I'd just handed it to a
website I'd never looked at, run by people I can't name, covered in crypto ads.

Probably fine. Probably.

That "probably" is what bothered me — because I do this constantly. Format a
payload. Decode a token. Work out what a cron expression means. Convert a
timestamp. Every time, I hand internal data to a site I haven't vetted.

So I built the alternative.

DevPocket → 12 developer tools that run entirely in your browser.

No backend. No analytics. No sign-up. Nothing you paste is ever uploaded,
because there is no server for it to go to.

You don't have to take my word for it: open DevTools, Network tab, paste a
token. Nothing leaves the page.

What's inside:
· JSON / XML formatter with path search
· SQL formatter across 11 dialects
· JSON → TypeScript, Go, Java, Python, C# models
· Cron builder with the next 8 run times
· Timestamps across IST, SAST and UTC at once
· JWT decoder, diff checker, mock data generator, HTTP reference

One deliberate omission: the JWT tool doesn't verify signatures. It could —
but that means asking you to paste your signing secret into a web page, and
I'm not building a tool that argues against itself.

Free, no catch. If a tool you need is missing, tell me.

devpocket.in

#WebDevelopment #SoftwareEngineering #DeveloperTools #JavaScript #React
```

---

## Option B — short and punchy

For a second post a week or two later, or if you prefer less text.

```
Every "free online JSON formatter" has the same business model.

You paste your data. They keep it.

Sometimes that data is a production token, a customer record, or an internal
API response. We all do it, and we mostly don't think about it.

So I built DevPocket — 12 developer tools with no backend at all.

Everything runs in your browser tab. There's no server to send data to, so
nothing you paste can leave. That's not a privacy policy, it's architecture.

JSON, XML, SQL, JWT, cron, diffs, timestamps, mock data, HTTP reference.

Free. No sign-up. No ads.

devpocket.in

#SoftwareEngineering #WebDevelopment #DeveloperTools #Privacy
```

---

## Option C — the lessons angle

LinkedIn's algorithm and audience both reward "what I learned". Good as a
follow-up post once the launch one has run.

```
I shipped a side project last week. Three things surprised me.

1. Removing the backend removed almost all the work.

No auth. No database. No rate limiting. No server costs. No privacy policy
to write. It's a static site — it'll still be running in five years because
there's nothing to keep running.

2. The best feature came from a real annoyance, not a feature list.

I work with people in India and South Africa. "The job runs at 2am" is a
useless sentence unless everyone knows whose 2am. So the time tool shows
local, IST, SAST and UTC simultaneously. It's the thing I use most.

3. Saying no made the product more trustworthy.

The JWT tool decodes tokens but won't verify signatures — that would mean
asking you to paste your signing secret into a web page. A slightly less
capable tool that doesn't undermine its own argument.

DevPocket → 12 developer tools that never send your data anywhere.

devpocket.in

#BuildInPublic #SoftwareEngineering #WebDevelopment #SideProject
```

---

## Mechanics

**Length.** All three sit under LinkedIn's 3,000-character limit. Option A is
the longest and that's fine — long posts perform well when the first two lines
hook. Keep the whitespace; walls of text get scrolled past.

**The link.** It is widely reported that posts with external links get less
reach than posts without. Two approaches:

- Safer: leave the URL out of the post, end with "Link in the comments", then
  post `devpocket.in` as your own first comment immediately after publishing.
- Simpler: leave the link in the post as written above. The reach penalty is
  real but modest, and for a launch post the click-through matters more than
  impressions.

I'd use the link in the post for the launch, and link-in-comments for follow-ups.

**Hashtags.** Three to five, at the end. More than five reads as spam. The ones
above are chosen for volume without being generic (#coding and #tech are too
broad to help).

**Timing.** Tuesday to Thursday, 9–11am IST. Avoid Friday afternoon and weekends.

**The first hour matters most.** LinkedIn decides a post's reach largely on early
engagement, so:

- Reply to every comment, properly — a real answer, not "thanks!"
- Don't edit the post in the first hour if you can avoid it
- Ask one or two people who'd genuinely find it useful to take a look

**Images.** A single screenshot outperforms none. Use the timezone panel from
/timestamp in dark mode — it's the most visually distinctive screen and it
illustrates the point in Option C. Native images beat link previews for reach.

**Follow-up.** Don't post all three at once. Space them a week or two apart, and
only post B or C if A gets traction — otherwise it reads as repetition.
