# Medium post — DevPocket launch

---

## Title options

1. **I Stopped Pasting Production Tokens Into Random Websites, So I Built My Own Toolbox**
2. **Every Developer Tool Site Wants Your Data. I Built One That Can't Take It.**
3. **12 Developer Tools That Never Send Your Data Anywhere**

*Recommended: option 1 — it's a story, not a product pitch, and Medium's audience responds to the former.*

## Subtitle

> A local-first toolbox for the small things backend developers do a dozen times a day — and why I made sure it has no server at all.

---

## Body — paste from here down

I was debugging an auth issue at 11pm when I caught myself doing something I'd done a hundred times without thinking.

I copied a JWT out of a production request log, opened a new tab, searched "jwt decoder", clicked the first result, and pasted it in.

Then I stopped. That token belonged to a real user. I had just handed it to a website I'd never looked at, run by people I couldn't name, that was covered in ads for crypto exchanges. I had no idea whether it decoded that token in my browser or shipped it to a server in some other country and logged it forever.

Probably it was fine. Probably.

That "probably" is the part that bothered me. I do this constantly — format a JSON payload, decode a token, work out what a cron expression means, convert a timestamp. Every one of those little tasks sends me to a site I haven't vetted, and half the time the thing I'm pasting is customer data, an internal API response, or a credential.

So I built the alternative. It's called **DevPocket**, it's free, and the entire design rests on one rule.

### The rule: there is no server

DevPocket has no backend. Not a small one, not a "we only log anonymised requests" one — none at all. Every tool runs as JavaScript in your own browser tab. There's no API to call, no database to write to, no analytics collecting what you paste.

This isn't a promise I'm asking you to trust. It's a structural fact you can verify: open DevTools, go to the Network tab, and paste a token in. Nothing goes out. There's nowhere for it to go.

That constraint shaped everything else. It rules out server-side processing, which means every tool has to work with what browsers can already do — and browsers can do a surprising amount.

### What's in it

Twelve tools, grouped by the kind of work they belong to.

**Data** — a JSON and XML formatter that also *searches*: paste an API response and it'll tell you every path where a field appears, which beats scrolling through 400 lines looking for one key. A JSON ⇄ YAML ⇄ CSV converter for the config-file shuffling that DevOps work involves. A generator that turns a JSON payload into typed models — TypeScript interfaces, Go structs, Java POJOs, Python dataclasses or C# classes, nested types included. And a SQL formatter covering 11 dialects.

**Text** — a diff checker, Base64 and URL encoding, hashing, and a JWT decoder.

**Time** — timestamp conversion, UUID generation, a live regex tester, and a cron builder.

**Reference** — a searchable HTTP status code, method and header reference, and a mock data generator that outputs JSON, CSV or ready-to-run SQL `INSERT` statements.

### Three bits I'm actually pleased with

**The timezone panel.** I work with people in India and South Africa. "The job runs at 2am" is a useless sentence unless everyone knows *whose* 2am. So the time tool shows the same instant across your local time, IST, SAST and UTC simultaneously — and when you paste a Unix timestamp, you get all four at once instead of converting one at a time.

**The cron builder** tells you what an expression means in plain English *and* shows the next eight times it will actually fire. Reading `0 9 * * 1-5` and knowing it means weekdays at 9am is one thing. Seeing that it fires Friday the 4th and then jumps to Monday the 7th is what actually catches the bug.

**The HTTP reference** exists because I have looked up the difference between 409 and 422 more times than I want to admit. Now it's a tab away with no cookie banner in between.

### What it deliberately doesn't do

The JWT tool decodes tokens and checks their structure, algorithm and expiry. It does **not** verify signatures.

It could — the crypto is available in the browser. But verifying a signature means asking you to paste your signing secret into a web page, and I'm not going to build a tool whose whole premise is "don't paste secrets into web pages" and then ask you to paste a secret into a web page.

So it shows the signature and says plainly that it isn't verified. A slightly less capable tool that doesn't undermine its own argument.

### How it's built

React and Vite, Tailwind CSS v4, deployed as static files on GitHub Pages. Routes are code-split, so opening the SQL formatter doesn't make the JSON tool slower — the initial load is about 87KB gzipped and the heavy dependencies only arrive when you open the tool that needs them.

There's a command palette on ⌘K, light and dark themes, and it works on a phone. Nothing exotic. The interesting constraint wasn't technical, it was the refusal to add a backend — which turns out to remove an enormous amount of work. No auth, no rate limiting, no database, no server costs, no privacy policy to write. It's a static site. It'll still be up in five years because there's nothing to keep running.

### It's free, and it's not a startup

There's no sign-up, no pro tier, no email capture, no ads. I built it because I wanted it to exist. If it's useful to you, use it.

If something's broken or a tool you need is missing, I'd genuinely like to know — the list of twelve is just the things *I* reach for, and that's a narrow sample.

**→ [devpocket.in](https://devpocket.in)**

---

## Medium publishing checklist

**Tags** (Medium allows 5 — these balance reach and relevance):

```
Programming
Web Development
Developer Tools
JavaScript
Productivity
```

**Cover image:** use `public/og.png` from the repo — the 1200×630 share card. It's already sized for a Medium header.

**Screenshots worth adding inline** (take these yourself at a wide window, dark mode looks best):

- The timezone panel on `/timestamp` — the four-clock row is the most visually distinctive thing on the site
- The cron builder on `/cron` showing the next-8-runs list
- The JSON → Code page mid-generation, showing JSON on the left and TypeScript on the right

Place them right after the paragraph that describes each.

**Links:** the one at the bottom is the main call to action. Add one more early — hyperlink the first mention of "**DevPocket**" in the "The rule" section. Two is plenty; more reads as spam.

**Do NOT set a canonical URL.** That setting is for republishing something already on your own site. This post is original to Medium, so leave it blank — otherwise you'd be pointing Google away from the post.

**Timing:** Tuesday–Thursday, 9–11am IST tends to catch both the Indian and European morning. Avoid weekends.

**After publishing:**

1. Post the Medium link to LinkedIn with a two-line summary — don't just drop the URL
2. Share to **r/webdev** and **r/SideProject** — but link to `devpocket.in` directly there, not the Medium post. Reddit dislikes being funnelled to blog posts. Lead with the privacy angle in the title.
3. Consider a **Show HN** on Hacker News. Low hit rate, but the upside is larger than everything else combined.
4. Submit the Medium post to a publication if you can — *Better Programming*, *Level Up Coding* or *JavaScript in Plain English* all take submissions and have far bigger audiences than a personal profile.

**A note on expectations:** Medium's outbound links are `nofollow`, so this won't directly boost your Google ranking. What it does is get your new domain crawled quickly, and let Medium's authority rank the *article* for terms your site can't reach yet. Treat it as distribution, not link building.
